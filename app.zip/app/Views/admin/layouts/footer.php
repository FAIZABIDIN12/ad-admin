<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; ASRI GRAHA HOTEL 2024</span>
        </div>
    </div>
</footer>